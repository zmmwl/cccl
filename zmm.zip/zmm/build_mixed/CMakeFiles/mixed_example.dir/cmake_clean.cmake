file(REMOVE_RECURSE
  "CMakeFiles/mixed_example.dir/mixed_example.cu.o"
  "CMakeFiles/mixed_example.dir/mixed_example.cu.o.d"
  "bin/mixed_example"
  "bin/mixed_example.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/mixed_example.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
