# Empty dependencies file for mixed_example.
# This may be replaced when dependencies are built.
