file(REMOVE_RECURSE
  "CMakeFiles/show_mixed_help"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/show_mixed_help.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
