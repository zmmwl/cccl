file(REMOVE_RECURSE
  "CMakeFiles/performance_comparison"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/performance_comparison.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
