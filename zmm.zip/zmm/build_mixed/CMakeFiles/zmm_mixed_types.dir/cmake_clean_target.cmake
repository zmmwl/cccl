file(REMOVE_RECURSE
  "libzmm_mixed_types.a"
)
