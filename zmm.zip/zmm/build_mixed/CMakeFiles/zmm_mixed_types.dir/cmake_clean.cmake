file(REMOVE_RECURSE
  "CMakeFiles/zmm_mixed_types.dir/mixed_column_processor.cu.o"
  "CMakeFiles/zmm_mixed_types.dir/mixed_column_processor.cu.o.d"
  "CMakeFiles/zmm_mixed_types.dir/mixed_kernels.cu.o"
  "CMakeFiles/zmm_mixed_types.dir/mixed_kernels.cu.o.d"
  "CMakeFiles/zmm_mixed_types.dir/mixed_types.cu.o"
  "CMakeFiles/zmm_mixed_types.dir/mixed_types.cu.o.d"
  "libzmm_mixed_types.a"
  "libzmm_mixed_types.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/zmm_mixed_types.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
