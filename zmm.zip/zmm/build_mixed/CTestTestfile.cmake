# CMake generated Testfile for 
# Source directory: /mnt/c/dev/ml/cuda/cccl-zmm-v2.8.5/zmm
# Build directory: /mnt/c/dev/ml/cuda/cccl-zmm-v2.8.5/zmm/build_mixed
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(mixed_test "/mnt/c/dev/ml/cuda/cccl-zmm-v2.8.5/zmm/build_mixed/bin/mixed_example")
set_tests_properties(mixed_test PROPERTIES  _BACKTRACE_TRIPLES "/mnt/c/dev/ml/cuda/cccl-zmm-v2.8.5/zmm/CMakeLists.txt;89;add_test;/mnt/c/dev/ml/cuda/cccl-zmm-v2.8.5/zmm/CMakeLists.txt;0;")
